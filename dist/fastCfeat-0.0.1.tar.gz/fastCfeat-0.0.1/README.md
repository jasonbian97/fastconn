# Fast connectivity feature extraction
